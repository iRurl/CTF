<?php
error_reporting(0);
highlight_file(__FILE__);
class A{
    public $a;
    public function __construct($a)
    {
        $this->a = $a;
    }
    public function __destruct()
    {
        foreach (explode("-",$this->a) as $value){
            echo $value." ";
        }
    }
}
class B extends C {
    public $c;
    public function FileReader(){
        if (file_exists($this->c)){
            echo file_get_contents($this->c);
        }else{
            echo "file_not_found";
        }
    }
    public function __toString()
    {
        $this->FileReader();
        return "";
    }

}
class C{
    public $what;
    public $haha;
    public function __wakeup()
    {
        $this->c = "no way";
        $this->what = $this->haha;

    }
}


$p = $_GET["p"];
if (isset($p)){
    unserialize($p);
}else{
    new A("Welcome-hacker");
}
